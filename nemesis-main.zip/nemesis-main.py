import operator
import time
from time import sleep
import tkinter
import platform
import re
from os import startfile
import bs4
from pyowm import OWM
import ctypes
import winshell
from tkinter import Label
from tkinter import Entry
from tkinter import Button
from tkinter import Tk
from tkinter import StringVar
from email.message import EmailMessage
import pytube
import self as self
from pytube import YouTube
import PyPDF2
import pywikihow
from pywikihow import search_wikihow
import requests
import wolframalpha
from pytube import YouTube
from playsound import playsound
import pyttsx3
import speech_recognition as sr
import datetime
import os
import os.path
import cv2
import random
from keyboard import press
from keyboard import press_and_release
from keyboard import write
import requests
from requests import get
import wikipedia
import webbrowser
import webbrowser as web
from webbrowser import Chrome
import pywhatkit as kit
from ecapture import ecapture as ec
import smtplib
import sys
import pyjokes
import pyautogui
from pyautogui import click
from pyautogui import hotkey
import pyperclip
from bs4 import BeautifulSoup
import speedtest
import psutil
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import QTimer, QTime, QDate, Qt
from PyQt5.QtGui import QMovie
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PIL import ImageGrab
import numpy as np

# from PyQt5.uic import loadUiType
from nemesis import Ui_nemesisUi

# Main Nemesis Code ############

engine = pyttsx3.init('sapi5')
voice = engine.getProperty('voices')
# print(voice)
engine.setProperty('voice', voice[0].id)


# Text to speech


def speak(audio):
    engine.say(audio)
    print(audio)
    engine.runAndWait()


def startup():
    speak("Initializing NEMESIS....")
    # speak("Starting all System Applications, Installing and Checking all Drivers....")
    # speak("Checking the Internet Connection....")
    # speak("Wait a moment Sir....")
    # speak("All drivers are Up and Running, All systems have been Activated !")
    # speak("Now I am online")


# To wish


def wish():
    hour = int(datetime.datetime.now().hour)
    tt = time.strftime("%I:%M %p")

    if 0 <= hour <= 12:
        speak(f"Good Morning, it's {tt}")
    elif 12 < hour < 18:
        speak(f"Good Afternoon, it's {tt}")
    else:
        speak(f"Good Evening, it's {tt}")
    speak("I am NEMESIS. Please tell me how may I help you Sir")


# To get news updates


def news():
    main_url = 'http://newsapi.org/v2/top-headlines?sources=techcrunch&apikey=14b0ce96ed2c46e5a98a65512fbd73c0'

    main_page = requests.get(main_url).json()
    articles = main_page["articles"]
    head = []
    day = ["first", "second", "third", "fourth", "fifth", "sixth", "seventh"]
    for ar in articles:
        head.append(ar["title"])
    for i in range(len(day)):
        speak(f"Today's {day[i]} news is: {head[i]}")


# To read pdf files


def pdf_reader():
    book = open('E://python_tutorial.pdf', 'rb')
    pdf_reader1 = PyPDF2.PdfFileReader(book)
    pages = pdf_reader1.numPages
    speak(f"Total number of pages in this book {pages} ")
    speak("Sir, Please enter the page number I have to read")
    pg = int(input("Please enter the page number : "))
    page = pdf_reader1.getPage(pg)
    text = page.extractText()
    speak(text)


# To check internet speed


def SpeedTest():
    speak("Checking Speed....")
    speed = speedtest.Speedtest()
    downloading = speed.download()
    correctDown = int(downloading / 800000)
    uploading = speed.upload()
    correctUpload = int(uploading / 800000)
    speak(f"The Uploading Speed is {correctUpload} mbps and The Downloading Speed is {correctDown} mbps")


def YoutubeSearch(term):
    result = "https://www.youtube.com/results?search_query=" + term
    web.open(result)
    speak("This is what I found for you Sir.")
    kit.playonyt(term)
    speak("This May also help you Sir.")


def cpu():
    usage = str(psutil.cpu_percent())
    speak("CPU is at " + usage + "%")


def computational_intelligence(question):
    api_key = "LQ74PY-H6LVLGXE38"
    client = wolframalpha.Client(api_key)
    answer = client.query(question)
    try:
        answer = next(answer.results).text
        return answer
    except Exception as e:
        speak("Sorry sir I couldn't fetch your question's answer. Please try again ")


def CoronaVirus(Country):
    countries = str(Country).replace(" ", "")
    url = f"https://www.worldometers.info/coronavirus/country/{countries}/"
    result = requests.get(url)
    soups = bs4.BeautifulSoup(result.text, 'lxml')
    corona = soups.find_all('div', class_='maincounter-number')
    Data = []
    for case in corona:
        span = case.find('span')
        Data.append(span.string)
    cases, death, recovered = Data
    speak(f"Total Active Cases : {cases}")
    speak(f"Total Deaths : {death}")
    speak(f"Total Recovered Cases : {recovered}")


def systemInfo():
    speak("Sir here is our system info..")
    os.system('cmd /k "systeminfo"')


class MainThread(QThread):
    def __init__(self):
        super(MainThread, self).__init__()

    def run(self):
        recognizer = cv2.face.LBPHFaceRecognizer_create()  # Local Binary Patterns Histograms
        recognizer.read('trainer/trainer.yml')  # load trained model
        cascadePath = "haarcascade_frontalface_default.xml"
        faceCascade = cv2.CascadeClassifier(cascadePath)  # initializing haar cascade for object detection approach

        font = cv2.FONT_HERSHEY_SIMPLEX  # denotes the font type

        id = 3  # number of persons you want to Recognize
        names = ['', 'Amartya']  # names, leave first empty bcz counter starts from 0

        cam = cv2.VideoCapture(0, cv2.CAP_DSHOW)  # cv2.CAP_DSHOW to remove warning
        cam.set(3, 640)  # set video FrameWidht
        cam.set(4, 480)  # set video FrameHeight

        # Define min window size to be recognized as a face
        minW = 0.1 * cam.get(3)
        minH = 0.1 * cam.get(4)

        # flag = True

        while True:
            ret, img = cam.read()  # read the frames using the above created object
            converted_image = cv2.cvtColor(img,
                                           cv2.COLOR_BGR2GRAY)  # The function converts an input image from one color space to another

            faces = faceCascade.detectMultiScale(
                converted_image,
                scaleFactor=1.2,
                minNeighbors=5,
                minSize=(int(minW), int(minH)),
            )

            for (x, y, w, h) in faces:
                cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)  # used to draw a rectangle on any image
                id, accuracy = recognizer.predict(converted_image[y:y + h, x:x + w])  # to predict on every single image
                # Check if accuracy is less them 100 ==> "0" is perfect match
                if accuracy < 100:
                    id = names[id]
                    accuracy = "  {0}%".format(round(100 - accuracy))
                    speak("Verification Successful")
                    pyautogui.press('esc')
                else:
                    id = "unknown"
                    accuracy = "  {0}%".format(round(100 - accuracy))
                    speak("Not Verified, try again")

                cv2.putText(img, str(id), (x + 5, y - 5), font, 1, (255, 255, 255), 2)
                cv2.putText(img, str(accuracy), (x + 5, y + h - 5), font, 1, (255, 255, 0), 1)

            cv2.imshow('camera', img)
            k = cv2.waitKey(10) & 0xff  # Press 'ESC' for exiting video
            if k == 27:
                break

        # Do a bit of cleanup
        # print("Thanks for using this program, have a good day.")
        cam.release()
        cv2.destroyAllWindows()
        # speak("Please say Wake Up to continue..")
        while True:
            # self.query = self.takecommand()
            # if "wake up" in self.query or "are you there" in self.query:
            self.TaskExecution()

    # To convert voice to text

    def takecommand(self):
        r = sr.Recognizer()
        with sr.Microphone() as source:
            print("Listening....")
            r.pause_threshold = 1
            audio = r.listen(source, timeout={}, phrase_time_limit=8)
        try:
            print("Recognizing....")
            self.query = r.recognize_google(audio, language='en-in')
            print(f"User Said: {self.query}")

        except Exception as e:
            speak("Say that again please....")
            return "none"
        return self.query

    def TaskExecution(self):
        # pyautogui.press('esc')
        # speak("Verification Successful")
        global time
        startup()
        wish()

        def ChromeAuto(command):
            query = str(command)
            if 'new tab' in query:
                press_and_release('ctrl + t')
            elif 'close tab' in query:
                press_and_release('ctrl + w')
            elif 'new window' in query:
                press_and_release('ctrl + n')
            elif 'history' in query:
                press_and_release('ctrl + h')
            elif 'download' in query:
                press_and_release('ctrl + j')
            elif 'bookmark' in query:
                press_and_release('ctrl + d')
                press('enter')
            elif 'incognito' in query:
                press_and_release('Ctrl + Shift + n')
            elif 'switch tab' in query:
                tab = query.replace("switch tab ", "")
                Tab = tab.replace("to", "")
                num = Tab
                bb = f'ctrl + {num}'
                press_and_release(bb)
            elif 'open' in query:
                name = query.replace("open ", "")
                NameA = str(name)
                if 'youtube' in NameA:
                    web.open("https://www.youtube.com/")
                elif 'instagram' in NameA:
                    web.open("https://www.instagram.com/")
                else:
                    string = "https://www." + NameA + ".com"
                    string_2 = string.replace(" ", "")
                    web.open(string_2)

        def WindiowsAuto(command):
            query = str(command)
            if 'home screen' in query:
                press_and_release('windows + m')
            elif 'minimize' in query:
                press_and_release('windows + m')
            elif 'show start' in query:
                press('windows')
            elif 'open setting' in query:
                press_and_release('windows + i')
            elif 'open search' in query:
                press_and_release('windows + s')
            elif 'screenshot' in query:
                press_and_release('windows + SHIFT + s')
            elif 'task manager' in query:
                press_and_release('Ctrl + SHIFT + Esc')
            elif 'restore windows' in query:
                press_and_release('Windows + Shift + M')
            else:
                speak("Sorry , No Command Found!")

        def send_email(receiver, subject, message):
            server = smtplib.SMTP('smtp.gmail.com', 587)
            server.starttls()
            # Make sure to give app access in your Google account
            server.login('virtualassistant2402@gmail.com', 'virtual7990')
            email = EmailMessage()
            email['From'] = 'virtualassistant2402@gmail.com'
            email['To'] = receiver
            email['Subject'] = subject
            email.set_content(message)
            server.send_message(email)

        email_list = {
            'amartya': 'amartyasrivastav@gmail.com',
            'amar': 'amartyasrivastavcr07as@gmail.com',
            'honey': 'honeychery2001@gmail.com',
            'shiva': 'tiwarishivakant019@gmail.com',
            'irene': 'irene@redvelvet.com',
            'vikas': 'vekta71@rediffmail.com'
        }

        def get_email_info():
            speak('To Whom you want to send email')
            name = self.takecommand().lower()
            receiver = email_list[name]
            print(receiver)
            speak('What is the subject of your email?')
            subject = self.takecommand()
            speak('Tell me the text in your email')
            message = self.takecommand()
            send_email(receiver, subject, message)
            speak('Great Sir Your email is sent')
            speak('Do you want to send more email?')
            send_more = self.takecommand()
            if 'yes' in send_more:
                get_email_info()

        def VideoDownloader():
            url = YouTube(str(link.get()))
            video = url.streams.first()
            video.download()
            Label(root, text="Downloaded", font='arial 15').place(x=180, y=210)

        def ScreenRecorder():
            # width = GetSystemMetrics(0)
            # height = GetSystemMetrics(1)
            time_stamp = datetime.datetime.now().strftime('%Y-%m-%d %H-%M-%S')
            file_name = f'{time_stamp}.mp4'
            fourcc = cv2.VideoWriter_fourcc('m', 'p', '4', 'v')
            captured_video = cv2.VideoWriter(file_name, fourcc, 10.0, (1920, 1080))

            # webcam = cv2.VideoCapture(0)

            while True:
                img = ImageGrab.grab(bbox=(0, 0, 1920, 1080))
                img_np = np.array(img)
                img_final = cv2.cvtColor(img_np, cv2.COLOR_BGR2RGB)
                # _, frame = webcam.read()
                # fr_height, fr_width, _ = frame.shape
                # img_final[0:fr_height, 0: fr_width, :] = frame[0: fr_height, 0: fr_width, :]
                cv2.imshow('Screen Capture', img_final)

                # cv2.imshow('webcam', frame)

                captured_video.write(img_final)
                if cv2.waitKey(10) == ord('q'):
                    break

        while True:

            self.query = self.takecommand().lower()

            # logic building for tasks

            if "open notepad" in self.query:
                speak("Opening Notepad")
                npath = "C:\\WINDOWS\\system32\\notepad.exe"
                os.startfile(npath)

            elif "open paint" in self.query:
                speak("Opening Paint")
                npath = "C:\\WINDOWS\\system32\\mspaint.exe"
                os.startfile(npath)

            elif "open command prompt" in self.query:
                speak("Opening Command Prompt")
                os.system("start cmd")

            elif "open spotify" in self.query:
                speak("Opening Spotify")
                npath = "C:\\Users\\amart\\AppData\\Roaming\\Spotify\\Spotify.exe"
                os.startfile(npath)

            elif "open camera" in self.query:
                speak("Opening Camera. You are looking good sir !")
                cap = cv2.VideoCapture(0)
                while True:
                    ret, img = cap.read()
                    cv2.imshow('webcam', img)
                    k = cv2.waitKey(50)
                    if k == 27:
                        break
                cap.release()
                cv2.destroyAllWindows()

            elif "on chrome" in self.query or "chrome" in self.query:
                ChromeAuto(self.query)

            elif "on window" in self.query or "window" in self.query:
                WindiowsAuto(self.query)

            elif "covid cases" in self.query:
                speak("Sir Please tell me the Country's Name")
                cmd = self.takecommand()
                CoronaVirus(cmd)
                speak("Here is your information Sir....")

            elif "hide all files" in self.query or "hide this folder" in self.query:
                speak("Okay Sir Hiding Files of the Main Directory")
                os.system("attrib +h /s /d")
                speak("All the files are now hidden")

            elif "visible all files" in self.query or "unhide all files" in self.query or "unhide this folder" in self.query:
                speak("Okay Sir Unhiding all files of the Main Directory")
                os.system("attrib -h /s /d")
                speak("All the files are now visible")

            elif "play music" in self.query:
                speak("Okay Sir, Playing Music from our Music Directory")
                music_dir = "D:\\Song"
                songs = os.listdir(music_dir)
                rd = random.choice(songs)
                os.startfile(os.path.join(music_dir, rd))

            elif "volume down" in self.query:
                pyautogui.press("volumedown")

            elif "volume up" in self.query:
                pyautogui.press("volumeup")

            elif "volume mute" in self.query:
                pyautogui.press("volumemute")

            elif "set alarm" in self.query:
                speak("Please Enter the time")
                time = input("Enter the Time = ")

                while True:
                    Time_Ac = datetime.datetime.now()
                    now = Time_Ac.strftime("%H:%M:%S")

                    if now == time:
                        speak("Time to wake up Sir !")
                        playsound('D:\\Song\\alarm.mp3')
                        speak("Alarm Closed !")

                    elif now > time:
                        break

            elif 'timer' in self.query or 'stopwatch' in self.query:
                speak("For how many minutes?")
                timing = self.takecommand()
                timing = timing.replace('minutes', '')
                timing = timing.replace('minute', '')
                timing = timing.replace('for', '')
                timing = float(timing)
                timing = timing * 60
                speak(f'I will remind you in {timing} seconds')

                time.sleep(timing)
                speak('Your time has been finished sir')

            elif "ip address" in self.query:
                ip = get('https://api.ipify.org').text
                speak(f"Your IP address is {ip}")

            elif "where i am" in self.query or "where we are" in self.query:
                speak("Wait Sir, Let me check")
                try:
                    cl = "https://www.google.com/maps/place/Jaipur,+Rajasthan/@26.8851413,75.6501284," \
                         "50121m/data=!3m2!1e3!4b1!4m5!3m4!1s0x396c4adf4c57e281:0xce1c63a0cf22e09!8m2!3d26.9124336" \
                         "!4d75.7872709 "
                    speak("Checking....")
                    web.open(cl)
                    ip_add = requests.get('https://api.ipify.org').text
                    print(ip_add)
                    url = 'https://get.geojs.io/v1/ip/geo/' + ip_add + '.json'
                    geo_request = requests.get(url)
                    geo_data = geo_request.json()
                    city = geo_data['city']
                    # state = geo_data['state']
                    country = geo_data['country']
                    speak(f"Sir I am not sure, but I think we are in {city} city of {country} country")

                except Exception as e:
                    speak("Sorry Sir, Due to network issue I am unable to find where we are.")

            elif "where is" in self.query:
                query = self.query.replace("where is", "")
                location = query
                speak("Sir You asked me to Locate..")
                speak(f"Hold on Sir, Finding {location} on Maps..")
                webbrowser.open("https://www.google.nl/maps/place/" + location + "")
                speak(f"Sir I am not sure, but according to me here is {location}")

            elif "how much power is left" in self.query or "battery status" in self.query:
                battery = psutil.sensors_battery()
                percentage = battery.percent
                speak(f"Sir our system have {percentage} percent battery")
                if percentage >= 50:
                    speak("We have enough power to continue with our work")
                elif 50 > percentage >= 30:
                    speak("Sir, soon We should connect our system to charging supply")
                elif 30 > percentage >= 15:
                    speak("Sir, We don't have enough power to work, Please connect to a power supply")
                elif percentage < 15:
                    speak("Critical Warning....")
                    speak(
                        "Sir, We will soon lose power and System will shutdown, Please connect to power supply asap !")

            elif "record screen" in self.query or "screen recording" in self.query:
                speak("Starting Screen Recording.")
                ScreenRecorder()


            elif "system" in self.query or "system info" in self.query:
                systemInfo()

            elif "wikipedia" in self.query:
                speak("Searching Wikipedia....")
                self.query = self.query.replace("wikipedia", "")
                results = wikipedia.summary(self.query, sentences=5)
                speak("According to Wikipedia")
                speak(results)
                # print(results)

            elif "how to" in self.query:
                speak("Getting Data from Internet..")
                op = self.query.replace("nemesis", "")
                max_result = 1
                how_to_func = search_wikihow(op, max_result)
                assert len(how_to_func) == 1
                how_to_func[0].print()
                speak(how_to_func[0].summary)

            elif "cpu" in self.query or "cpu stats" in self.query:
                cpu()

            elif "calculate" in self.query:
                app_id = "LQ74PY-H6LVLGXE38"
                client = wolframalpha.Client(app_id)
                indx = self.query.lower().split().index('calculate')
                query = self.query.split()[indx + 1:]
                res = client.query(' '.join(query))
                answer = next(res.results).text
                speak("The answer is " + answer)

            elif "what is" in self.query or "where is" in self.query:
                question = self.query
                answer = computational_intelligence(question)
                speak(answer)

            elif "who is" in self.query or "which is" in self.query:
                question = self.query
                answer = computational_intelligence(question)
                speak(answer)

            elif "read pdf files" in self.query:
                pdf_reader()

            elif "tell me a joke" in self.query:
                joke = pyjokes.get_joke()
                speak(joke)

            elif "open youtube" in self.query:
                webbrowser.open("www.youtube.com")

            elif "youtube search" in self.query or "search youtube" in self.query:
                Query = self.query.replace("nemesis", "")
                YoutubeSearch(self.query)

            elif "temperature today" in self.query:
                search = "temperature in gandhidham"
                url = f"https://www.google.com/search?q={search}"
                r = requests.get(url)
                data = BeautifulSoup(r.text, "html.parser")
                temp = data.find("div", class_="BNeawe").text
                speak(f"Current {search} is {temp}")

            elif "download video" in self.query:
                root = Tk()
                root.geometry('500x300')
                root.resizable(0, 0)
                root.title("YouTube Video Downloader")
                speak("Enter Video URL Here !")
                Label(root, text="Youtube Video Downloader", font='arial 15 bold').pack()
                link = StringVar()
                Label(root, text="Paste Video URL Here", font='arial 15 bold').place(x=110, y=60)
                Entry(root, width=53, textvariable=link).place(x=32, y=120)
                Button(root, text="Download", font='arial 15 bold', bg='pale green', padx=2,
                       command=VideoDownloader).place(x=180, y=170)
                root.mainloop()
                speak("Video Downloaded")

            # elif "download video" in self.query:
            #     DownloadYoutube()

            elif "open linkedin" in self.query:
                webbrowser.open("linkedin.com/in/amartya-srivastav-0ba6031aa")

            elif 'open stack overflow' in self.query:
                webbrowser.open('https://stackoverflow.com')

            elif "open gmail" in self.query:
                webbrowser.open("https://mail.google.com/mail/u/0/?tab=rm&ogbl#inbox")

            elif "open google" in self.query:
                speak("Sir, what should I search on google ?")
                cm = self.takecommand().lower()
                webbrowser.open(f"{cm}")

            elif 'github' in self.query:
                webbrowser.open('https://github.com/Amartya-Srivastav/')

            elif "send message on whatsapp" in self.query:
                kit.sendwhatmsg("+917990123643", "Hi, This is testing message", 12, 57)

            elif "send text message" in self.query or "message as text" in self.query:
                speak("Sir, What Should I say ?")
                mesg = self.takecommand()

                from twilio.rest import Client

                account_sid = 'ACa5ba4bf1eca0477686e6c1bb3a90abbd'
                auth_token = '157e05e39732a49fae80c1187ecbed02'
                client = Client(account_sid, auth_token)

                message = client.messages \
                    .create(
                    body=mesg,
                    from_='+15126300202',
                    to='+919624162746'
                )

                print(message.sid)
                speak("Sir, Text Message has been Sent")

            elif "make a call" in self.query or "call me" in self.query or "make a phone call" in self.query:
                speak("Okay Sir, Calling For You")

                from twilio.rest import Client

                account_sid = 'ACa5ba4bf1eca0477686e6c1bb3a90abbd'
                auth_token = '157e05e39732a49fae80c1187ecbed02'
                client = Client(account_sid, auth_token)

                message = client.calls \
                    .create(
                    twiml='<Response><Say>This is for only Testing purpose</Say></Response>',
                    from_='+15126300202',
                    to='+919624162746'
                )
                print(message.sid)
                speak("Please Wait for few Seconds Sir..")
                speak("Connecting your call..")
                print("Connecting......")
                # speak("Sir, Call Completed")

            elif "play songs on youtube" in self.query:
                kit.playonyt("jaane na doonga kahin")

            elif "send email" in self.query:
                get_email_info()

            elif "take screenshot" in self.query or "capture screenshot" in self.query:
                speak("Sir, Please mention the file name")
                name = self.takecommand().lower()
                speak("Please hold the screen for few seconds, I am taking screenshot.")
                time.sleep(2)
                img = pyautogui.screenshot()
                img.save(f"{name}.jpg")
                speak("Done sir, the screenshot is saved in our main folder. Ready for the next command")

            elif "remember that" in self.query:
                rememberMsg = self.query.replace("remember that", "")
                rememberMsg = rememberMsg.replace("NEMESIS", "")
                speak("Sir you told me to remind you that :" + rememberMsg)
                remember = open('data.txt', 'w')
                remember.write(rememberMsg)
                remember.close()

            elif "what do you remember" in self.query:
                remember = open('data.txt', 'r')
                speak("Sir, You told me that" + remember.read())

            elif "better than siri and alexa" in self.query:
                speak("Obviously Sir I am far more better than that stupid Siri and Alexa")

            elif "who are you" in self.query:
                speak("Sir, I am Nemesis, I am your personal virtual assistant, which work on Python and Machine "
                      "Learning Algo.")

            elif "hello nemesis" in self.query:
                speak("Hello Sir, May I help you with something ?")

            elif "how are you" in self.query:
                speak("I am Fine Sir, What about you ?")

            elif "i am also good" in self.query or "fine" in self.query:
                speak("That's great, to hear from you Sir.")

            elif "thank you" in self.query or "thanks" in self.query:
                speak("It's My pleasure Sir. ")

            elif "why you came to world" in self.query:
                speak("Thanks to My Creater. Further It's a secret")

            elif 'empty recycle bin' in self.query:
                winshell.recycle_bin().empty(confirm=False, show_progress=False, sound=True)
                speak("Recycle Bin Recycled")

            elif "shut down the system" in self.query:
                os.system("shutdown /s /t 5")

            elif "restart the system" in self.query:
                os.system("shutdown /r /t 5")

            elif "sleep the system" in self.query:
                os.system("rundll32.exe powrprof.dll, SetSuspendState 0,1,0")

            elif "switch the window" in self.query:
                pyautogui.keyDown("alt")
                pyautogui.press("tab")
                time.sleep(1)
                pyautogui.keyUp("alt")

            elif "tell me news" in self.query:
                speak("Please wait Sir, Fetching the latest news..")
                news()

            elif "who is my father" in self.query:
                speak("Your Fathers name is Vikas Srivastav, born on 21 feb 1971 He is Assistant Manager in Manaksia")

            elif "will you be my gf" in self.query or "will you be my bf" in self.query:
                speak("I'm not sure about, may be you should give me some time")

            elif "i love you" in self.query:
                speak("It's hard to understand")

            elif 'lock screen' in self.query:
                speak("locking the device")
                ctypes.windll.user32.LockWorkStation()

            elif "internet speed" in self.query:
                SpeedTest()

            # To close an application

            elif "close notepad" in self.query:
                speak("Okay Sir, closing Notepad")
                os.system("taskkill /f /im notepad.exe")

            elif "terminate paint" in self.query:
                speak("Okay Sir, closing Paint")
                os.system("taskkill /f /im mspaint.exe")

            elif "terminate camera" in self.query or "close camera" in self.query:
                speak("Okay Sir, closing Camera")
                os.system("taskkill /f /im webcam")

            elif "terminate command prompt" in self.query or "close cmd" in self.query:
                speak("Okay Sir, closing Command Prompt")
                os.system("taskkill /f /im close cmd")

            elif "you can sleep" in self.query or "sleep now" in self.query:
                speak("Okay Sir, I am going to sleep you can call me anytime.")
                break

            elif "quit now" in self.query or "exit now" in self.query:
                speak("Thanks for using me Sir, Have a Great day.")
                sys.exit()


startExecution = MainThread()


class Main(QMainWindow):

    def __init__(self):
        super().__init__()
        self.ui = Ui_nemesisUi()
        self.ui.setupUi(self)
        self.ui.pushButton_1.clicked.connect(self.startTask)
        self.ui.pushButton_2.clicked.connect(self.close)

    def startTask(self):
        self.ui.movie = QtGui.QMovie("N.E.M.E.S.I.S.gif")
        self.ui.main_gif.setMovie(self.ui.movie)
        self.ui.movie.start()

        startExecution.start()

        timer = QTimer(self)
        timer.timeout.connect(self.showTime)
        timer.start(1000)

    def showTime(self):
        current_time = QTime.currentTime()
        current_date = QDate.currentDate()
        label_time = current_time.toString('hh:mm:ss')
        label_date = current_date.toString(Qt.ISODate)
        self.ui.textBrowser_1.setText(label_date)
        self.ui.textBrowser_2.setText(label_time)


app = QApplication(sys.argv)
nemesis = Main()
nemesis.show()
exit(app.exec_())
