import time
import tkinter
from tkinter import Label
from tkinter import Entry
from tkinter import Button
from tkinter import Tk
from tkinter import StringVar
import pytube
import pywhatkit
from pytube import YouTube
import PyPDF2
import requests
from playsound import playsound
import pyttsx3
import speech_recognition as sr
import datetime
import os
import cv2
import random
from requests import get
import wikipedia
import webbrowser
import webbrowser as web
import pywhatkit as kit
import smtplib
import sys
import pyjokes
import pyautogui
from bs4 import BeautifulSoup
import speedtest

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
# print(voices[0].id)
engine.setProperty('voices', voices[0].id)

# Text to speech

def speak(audio):
    engine.say(audio)
    print(audio)
    engine.runAndWait()

# To convert voice to text

def takecommand():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening....")
        r.pause_threshold = 1
        audio = r.listen(source, timeout = {}, phrase_time_limit = 8)
    try:
        print("Recognizing....")
        query = r.recognize_google(audio, language='en-in')
        print(f"User Said: {query}")

    except Exception as e:
        speak("Say that again please....")
        return "none"
    return query

def startup():
    speak("Initializing NEMESIS....")
    speak("Starting all System Applications, Installing and Checking all Drivers....")
    speak("Checking the Internet Connection....")
    speak("Wait a moment Sir....")
    speak("All drivers are Up and Running, All systems have been Activated !")
    speak("Now I am online")

# To wish

def wish():
    hour = int(datetime.datetime.now().hour)
    tt = time.strftime("%I:%M %p")

    if hour >= 0 and hour <= 12:
        speak(f"Good Morning, it's {tt}")
    elif hour > 12 and hour < 18:
        speak(f"Good Afternoon, it's {tt}")
    else:
        speak(f"Good Evening, it's {tt}")
    speak("I am Jarvis. Please tell me how may I help you Sir")

# To send email

def sendEmail(to, content):
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.ehlo()
    server.starttls()
    server.login("virtualassistant2402@gmail.com", "virtual7990")
    server.sendmail("virtualassistant2402@gmail.com", to, content)
    server.close()

# To get news updates

def news():
    main_url = 'http://newsapi.org/v2/top-headlines?sources=techcrunch&apikey=14b0ce96ed2c46e5a98a65512fbd73c0'

    main_page = requests.get(main_url).json()
    articles = main_page["articles"]
    head = []
    day = ["first", "second", "third", "fourth", "fifth", "sixth", "seventh"]
    for ar in articles:
        head.append(ar["title"])
    for i in range(len(day)):
        speak(f"Today's {day[i]} news is: {head[i]}")

# To read pdf files

def pdf_reader():
    book = open('E://python_tutorial.pdf','rb')
    pdf_reader1 = PyPDF2.PdfFileReader(book)
    pages = pdf_reader1.numPages
    speak(f"Total number of pages in this book {pages} ")
    speak("Sir, Please enter the page number I have to read")
    pg = int(input("Please enter the page number : "))
    page = pdf_reader1.getPage(pg)
    text = page.extractText()
    speak(text)

# YouTube video download

def VideoDownloader():
    url = YouTube(str(link.get()))
    video = url.streams.first()
    video.download()
    Label(root, text = "Downloaded", font = 'arial 15').place(x=180, y= 210)

# To check internet speed

def SpeedTest():
    speak("Checking Speed....")
    speed = speedtest.Speedtest()
    downloading = speed.download()
    correctDown = int(downloading/800000)
    uploading = speed.upload()
    correctUpload = int(uploading/800000)

    if "uploading speed" in query:
        speak(f"The Uploading Speed is {correctUpload} mbps")
    elif "downloading speed" in query:
        speak(f"The Downloading Speed is {correctDown} mbps")
    else:
        speak(f"The Uploading Speed is {correctUpload} mbps and The Downloading Speed is {correctDown} mbps")

def YoutubeSearch(term):
    result = "https://www.youtube.com/results?search_query=" + term
    web.open(result)
    speak("This is what I found for you Sir.")
    pywhatkit.playonyt(term)
    speak("This May also help you Sir.")

if __name__ == "__main__":
    startup()
    wish()
    # takecommand()
    # speak("This is advanced Jarvis")

    while True:
    # if 1:

        query = takecommand().lower()

        # logic building for tasks

        if "open notepad" in query:
            speak("Opening Notepad")
            npath = "C:\\WINDOWS\\system32\\notepad.exe"
            os.startfile(npath)

        elif "open paint" in query:
            speak("Opening Paint")
            npath = "C:\\WINDOWS\\system32\\mspaint.exe"
            os.startfile(npath)

        elif "open command prompt" in query:
            speak("Opening Command Prompt")
            os.system("start cmd")

        elif "open camera" in query:
            speak("Opening Camera. You are looking good sir !")
            cap = cv2.VideoCapture(0)
            while True:
                ret, img = cap.read()
                cv2.imshow('webcam', img)
                k = cv2.waitKey(50)
                if k == 27:
                    break
            cap.release()
            cv2.destroyAllWindows()

        elif "play music" in query:
            music_dir = "D:\\Song"
            songs = os.listdir(music_dir)
            rd = random.choice(songs)
            os.startfile(os.path.join(music_dir, rd))

        elif "set alarm" in query:
            speak("Please Enter the time")
            time = input("Enter the Time = ")

            while True:
                Time_Ac = datetime.datetime.now()
                now = Time_Ac.strftime("%H:%M:%S")

                if now == time:
                    speak("Time to wake up Sir !")
                    playsound('D:\\Song\\alarm_beep_3.mp3')
                    speak("Alarm Closed !")

                elif now > time:
                    break

        elif "ip address" in query:
            ip = get('https://api.ipify.org').text
            speak(f"Your IP address is {ip}")

        elif "where i am" in query or "where we are" in query:
            speak("Wait Sir, Let me check")
            try:
                cl = "https://www.google.com/maps/place/Gandhidham,+Gujarat/@23.0702732,70.0835889,13944m/data=!3m2!1e3!4b1!4m5!3m4!1s0x3950b98e8bec0d97:0x9d6ccb522ee8f6e0!8m2!3d23.075297!4d70.133673"
                speak("Checking....")
                web.open(cl)
                ip_add = requests.get('https://api.ipify.org').text
                print(ip_add)
                url = 'https://get.geojs.io/v1/ip/geo/' + ip_add + '.json'
                geo_request = requests.get(url)
                geo_data = geo_request.json()
                city = geo_data['city']
                # state = geo_data['state']
                country = geo_data['country']
                speak(f"Sir I am not sure, but I think we are in {city} city of {country} country")

            except Exception as e:
                speak("Sorry Sir, Due to network issue I am unable to find where we are.")

        elif "wikipedia" in query:
            speak("Searching Wikipedia....")
            query = query.replace("wikipedia", "")
            results = wikipedia.summary(query, sentences = 5)
            speak("According to Wikipedia")
            speak(results)
            # print(results)

        elif "read pdf files" in query:
            pdf_reader()

        elif "tell me a joke" in query:
            joke = pyjokes.get_joke()
            speak(joke)

        elif "open youtube" in query:
            webbrowser.open("www.youtube.com")

        elif "temperature today" in query:
            search = "temperature in gandhidham"
            url = f"https://www.google.com/search?q={search}"
            r = requests.get(url)
            data = BeautifulSoup(r.text,"html.parser")
            temp = data.find("div", class_="BNeawe").text
            speak(f"Current {search} is {temp}")

        elif "download video" in query:
            root = Tk()
            root.geometry('500x300')
            root.resizable(0,0)
            root.title("YouTube Video Downloader")
            speak("Enter Video URL Here !")
            Label(root, text = "Youtube Video Downloader", font = 'arial 15 bold').pack()
            link = StringVar()
            Label(root, text = "Paste Video URL Here", font = 'arial 15 bold').place(x=110,y=60)
            Entry(root, width = 53, textvariable = link).place(x=32, y=120)
            Button(root, text = "Download", font = 'arial 15 bold', bg = 'pale green', padx = 2, command = VideoDownloader).place(x = 180, y = 170)
            root.mainloop()
            speak("Video Downloaded")

        elif "open linkedin" in query:
            webbrowser.open("linkedin.com/in/amartya-srivastav-0ba6031aa")

        elif "open gmail" in query:
            webbrowser.open("https://mail.google.com/mail/u/0/?tab=rm&ogbl#inbox")

        elif "open google" in query:
            speak("Sir, what should I search on google ?")
            cm = takecommand().lower()
            webbrowser.open(f"{cm}")

        elif "send message on whatsapp" in query:
            kit.sendwhatmsg("+917990123643", "Hi, This is testing message", 16, 41)

        elif "play songs on youtube" in query:
            kit.playonyt("jaane na doonga kahin")

        elif "youtube search" in query or "search youtube" in query:
            Query = query.replace("nemesis", "")
            YoutubeSearch(query)

        elif "email to amartya" in query:
            try:
                speak("what should I say ?")
                content = takecommand().lower()
                to = "amartyasrivastav@gmail.com"
                sendEmail(to, content)
                speak("Email has been sent to Amartya")

            except Exception as e:
                print(e)
                speak("Sorry Sir, I am unable to send email to Amartya")

        elif "take screenshot" in query or "capture screenshot" in query:
            speak("Sir, Please mention the file name")
            name = takecommand().lower()
            speak("Please hold the screen for few seconds, I am taking screenshot.")
            time.sleep(2)
            img = pyautogui.screenshot()
            img.save(f"{name}.jpg")
            speak("Done sir, the screenshot is saved in our main folder. Ready for the next command")

        # elif "remember that" in query:
        #     rememberMsg = query.replace("remember that", "")
        #     rememberMsg = rememberMsg.replace("Jarvis", "")
        #     speak("Sir you told me to remind you that :"+rememberMsg)
        #     remember = open('data.txt','w')
        #     remember.write(rememberMsg)
        #     remember.close()
        #
        # elif "what do you remember" in query:
        #     remember = open('data.txt', 'r')
        #     speak("Sir, You told me that"+remember.read())

        elif "better than siri and alexa" in query:
            speak("Obviously Sir I am far more better than that stupid Siri and Alexa")

        elif "who are you" in query:
            speak("Sir, I am your personal virtual assistant, which work on Python and Machine Learning Algo.")

        elif "shut down the system" in query:
            os.system("shutdown /s /t 5")

        elif "restart the system" in query:
            os.system("shutdown /r /t 5")

        elif "sleep the system" in query:
            os.system("rundll32.exe powrprof.dll, SetSuspendState 0,1,0")

        elif "switch the window" in query:
            pyautogui.keyDown("alt")
            pyautogui.press("tab")
            time.sleep(1)
            pyautogui.keyUp("alt")

        elif "tell me news" in query:
            speak("Please wait Sir, Fetching the latest news..")
            news()

        elif "who is my father" in query:
            speak("Your Fathers name is Vikas Srivastav, born on 21 february 1971 He is Assistant Manager in Manaksia")

        elif "uploading speed" in query:
            SpeedTest()

        elif "downloading speed" in query:
            SpeedTest()

        elif "internet speed" in query:
            SpeedTest()

        elif "hello jarvis" in query:
            speak("Hello Sir, May I help you with something ?")

        elif "how are you" in query:
            speak("I am Fine Sir, What about you ?")

        elif "i am also good" in query or "fine" in query:
            speak("That's great, to hear from you Sir.")

        elif "thank you" in query or "thanks" in query:
            speak("It's My pleasure Sir. ")


    # To close an application

        elif "close notepad" in query:
            speak("Okay Sir, closing Notepad")
            os.system("taskkill /f /im notepad.exe")

        elif "terminate paint" in query:
            speak("Okay Sir, closing Paint")
            os.system("taskkill /f /im mspaint.exe")

        elif "quit now" in query:
            speak("Thanks for using me Sir, Have a Great day.")
            sys.exit()



